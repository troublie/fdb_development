from django.apps import AppConfig


class FujiConfig(AppConfig):
    name = 'fuji'
